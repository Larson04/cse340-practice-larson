{
    "ext"; "js css ejs env",
    "exec"; "node --env-file=.env server.js",
    "ignore"; [
        ".git",
        "node_modules"
    ]
}